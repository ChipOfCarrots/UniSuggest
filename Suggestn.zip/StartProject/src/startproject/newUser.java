/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startproject;
import java.sql.*;
import java.util.Scanner;

/**
 *
 * @author Utente
 */
//acuisisco e immetto nel database
public class newUser { 
   private final Driver db = new Driver();
   private String new_name;
   private String new_email;
   private int new_age;
   private final String new_id = "NULL";
   private String new_pictures = "/text";
   private int new_sex;
   private String new_password;
   
public void insertNewUser (String name, String email, int age,int sex,String password) {
//mi connetto al db
    
    new_name = name;
    new_email = email;
    new_age = age;
    //cast da boul a int 1 = maschio 0= femm
    new_sex = sex ;
    new_password = password;
    
    
      String mySQL="INSERT INTO `user`(`id_u`, `name_u`, `password_u`, `age_u`, `picture_u`, `sex_u`, `email_u`) VALUES (NULL,'"+new_name+"','"+new_password+"','"+new_age+"','"+new_pictures+"','"+new_sex+"','"+new_email+"')";
        
     System.out.println(mySQL);
    db.executeStringUploadInMySQL(mySQL);

//acquisico le variabili 
//  ResultSet myRs = myStm.executeQuery("SELECT * FROM `suggest`");


}   
    
public boolean emailOrNameExicts(String email,String nome){
   boolean siorno = false; 
  siorno = db.checkEmailOrNameNewuser(email, nome);
    return siorno; 
}
public int sexGetNumber(String stringsex){
int sexn;
    if (stringsex.equals("M")){
            return sexn = 1;
        }else {return sexn = 0;}
}

    
}
