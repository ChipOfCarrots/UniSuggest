/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Utente
 */
public class allUser {
   private   String name_a;
   private String picture_a;
    private String email_a;
     private int age_a;
     private int sex_a;
    
      String name_u;
      String picture_u;
      String email_u;
      int age_u;
      int sex_u;
     
     
     
   Driver d = new Driver();
  
    private final String url1 = d.geturl();
    private final String user = d.getuser();
    private final String password = d.getpass();
    private Object allUserObj;
    
 //inserisce un User alla volta negli array caricato da Driver.getallUser   
 public void getAllUser(){ 
     
     try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {                
//System.out.println("hit");
                //se si è allacciato
    Statement myStm = myConn.createStatement();
    ResultSet allUserObj = myStm.executeQuery("SELECT  FROM `user`");}
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
           

   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
     
     /*try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {                
//System.out.println("hit");
                //se si è allacciato
    Statement myStm = myConn.createStatement();
    ResultSet allUserObj = myStm.executeQuery("SELECT * FROM `user`");}
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
           

   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }*/
 }
    /**
     *
     * @param email
     * @param pass
     */
 
 //chiamata dalla schermata per loggarsi
    public int findUserFromAccount(String email, String pass){
     int logId;
      
     
     try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {
      
                
//System.out.println("hit");
                //se si è allacciato
    Statement myStm = myConn.createStatement();
    ResultSet myRs = myStm.executeQuery("SELECT * FROM `user` WHERE `email_u` = '"+email+"' && `password_u` = '"+pass+"'");
               
    myRs.next();
        if (myRs.wasNull()){
            //ritorna meno uno se non trova niente nella query 
            return logId = -1; 
            
        } else {
            logId = myRs.getInt("id_u");
            
            return logId;
               }
            }
   } catch (SQLException ex) {
            System.out.println("");
           
           

   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
   } 
    
   return logId = -1;  
 }
 //chiamato dalla schermata per loggarsi acquisisce tutti la row dell id
public void findAccountById(int idToFind){
     
   
     
     try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {
      
                
//System.out.println("hit");
                //se si è allacciato
    Statement myStm = myConn.createStatement();
    ResultSet myRs = myStm.executeQuery("SELECT * FROM `user` WHERE `id_u` = '"+idToFind+"'");
        myRs.next();
        
        name_a = myRs.getString("name_u");
        picture_a = myRs.getString("picture_u");
        email_a = myRs.getString("email_u");
        age_a = myRs.getInt("age_u");
        sex_a = myRs.getInt("sex_u");
        
                System.out.println("alla User > accountfindId " + name_a);
        
    
            }
   } catch (SQLException ex) {
            System.err.println("Errore selezionamento utente");
            
           

   } catch (ClassNotFoundException e) {
    System.err.println("Errore selezionamento utente");
   }}
     
// spostamento di varibili per account
    public String getNameA (){    
        
     return name_a;
     }
    public String getEmailA (){    
     return email_a;
     }
    public int getAgeA (){    
     return age_a;
     }
    public int getSexA (){    
     return sex_a;
     }
    public String getPictureA (){    
     return picture_a;
     }
   //resetta le variabili in questa classe   
public void resetA (){
name_a = "";
email_a = "";
picture_a="";
sex_a = 0;
age_a = 0;
}    

public int getAgeU(){
return age_u;
}
public int getSexU(){
return sex_u;
}
public String getNameU(){
return name_u;
}

//quando abbiamo suggest troviamo lo user che l ha scritto
public void findUserById(int IdS){
     try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {               

                int findId;
    Statement myStm = myConn.createStatement();
    ResultSet SuggObj = myStm.executeQuery("SELECT `id_u_s` FROM `suggest` WHERE `id_s` = '"+IdS+"'");
   SuggObj.next();
   findId = Integer.parseInt(SuggObj.getString("id_u_s"));
                System.out.println("alluser> findiduser > id:" + findId); 
    ResultSet UserObj = myStm.executeQuery("SELECT `sex_u`,`name_u`,`age_u` FROM `user` WHERE `id_u` = '"+findId+"'");
    UserObj.next();
    name_u = UserObj.getString("name_u"); 
    sex_u = UserObj.getInt("sex_u");
    age_u = UserObj.getInt("age_u");
    System.out.println("allUser> findIdUser > name"+name_u+"sex"+sex_u+"age_u"+age_u);   
    
    
    
    
            }
   } catch (SQLException ex) {
            System.err.println("Errore selezione Utente in allUser");
            
   } catch (ClassNotFoundException e) {}
 }
    



     
     
     
 }
 
 
 
     
    

