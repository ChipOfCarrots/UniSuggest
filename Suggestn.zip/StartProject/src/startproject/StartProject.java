/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startproject;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;


/**
 *
 * @author Elia Poli 
 */
public class StartProject {
 
    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     * @throws java.lang.ClassNotFoundException
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        // TODO code application logic here
        Driver l = new Driver();
        l.getConnToDb();
        newUser newUse = new newUser(); 
        allUser utente = new allUser();
        account io = new account();
        Scanner in = new Scanner(System.in);
        newSuggest ns = new newSuggest();
        allSuggest sg = new allSuggest();
        String descr;
        int id_log;
      //  loggIn lg = new loggIn();
 //home_GUI home = new home_GUI();
 
       boolean y;
        String email;
        String pass;
        
ArrayList id = new ArrayList();

sg.getSuggestByLike();
id.addAll(sg.id_s);

int i = 0;
int idS;
String name;
int sex;
int age;

while(i <= sg.maxSuggLike){

    System.out.println("id in posizione:" + i + "è:" + id.get(i));
idS = Integer.parseInt(id.get(i).toString());
    utente.findUserById(idS);
name = utente.getNameU();
    System.out.println("nome utente:" + name);
sex = utente.getSexU();
age = utente.getAgeU();

 System.out.println("age utente:" + age);
  System.out.println("sex utente:" + sex);


i++;
}
 
 
 
 
 
 
 
 
 
 
 
 
 }
        
     
        
       
        /*
       System.out.println("inserisci email");
       email = in.nextLine();
       
       System.out.println("inserisci pass"); 
       pass = in.nextLine();
    
       y = newUse.emailOrNameExicts(email, pass);
       
       if (y){
       System.out.println("cazzo sgamato");
       }else{System.out.println("puoi farlo si con bob");}
       
       */
       /*
       io.findAdminFromAccount(email, pass);
       id_log = io.getAccountAdminId();
        System.out.println(id_log);
       
     //  io.check_Account(email, pass);
     //  id_log = io.getAccountId();
       
       
       
       /* 
        System.out.println("inserisci descr");
       descr = in.nextLine();
        ns.setInfoSugg(descr, id_log);
       */
       
        
        /*
        sg.getSuggestByLike();
        
        int i = 0;
        int idFindUs;
        String d;
        
        while(i <= sg.maxSuggLike){
            
           d =  sg.id_s_u_like.get(i).toString();
            
         idFindUs = Integer.parseInt(d);   
         
         utente.findUserById(idFindUs);
            System.out.print(utente.picture_u + "picture");
            System.out.print(utente.sex_u + "sesso" );
            System.out.print(utente.age_u + "age");
            System.out.print(utente.name_u + "ha scritto:\n");    
            
            System.out.println(sg.desc_s_like.get(i));
            System.out.print(sg.like_s_like.get(i)+ "like");
            System.out.println(sg.dislike_s_like.get(i)+ "dislike");
            
            
            i++;
        
        
        }
       */
       /*
         String e;
    System.out.println("inserisci idsugg"); 
      e  = in.nextLine();
      int y = Integer.parseInt(e);
      sg.addLike(y);
      sg.addDislike(y);
      sg.addAbuse(y);
      */
    }
   
  
    
    
    
    

