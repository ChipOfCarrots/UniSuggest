/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Utente
 */
public class allSuggest {
     Driver dri = new Driver();
    private final String url1 = dri.geturl();
    private final String user = dri.getuser();
    private final String password = dri.getpass();
    
    
    
    
    ArrayList id_s = new ArrayList();
    ArrayList desc_s = new ArrayList();
    ArrayList id_s_u = new ArrayList();
    ArrayList like_s = new ArrayList();
    ArrayList dislike_s = new ArrayList();
    
    allUser u = new allUser();
    int maxSuggLike; 
    public void getSuggestByLike() {
        
     try {
         
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {
id_s.clear();
    Statement myStm = myConn.createStatement();
    ResultSet allSuggObj = myStm.executeQuery("SELECT `id_s`, `desc_s`, `dislike_s`, `like_s`, `abuse_s`, `id_u_s` FROM `suggest` ORDER BY `like_s` DESC");
    
    int i = 0;
        while(allSuggObj.next()){
            maxSuggLike = i;
        id_s.add(i,allSuggObj.getInt("id_s"));
        
        //prova per vedere se cambia id_s
            System.out.println("da mostpop in alla suggest: "+id_s.get(i));
        
        
        id_s_u.add(i,allSuggObj.getInt("id_u_s"));
        desc_s.add(i,allSuggObj.getString("desc_s"));
        like_s.add(i,allSuggObj.getInt("like_s"));
        dislike_s.add(i,allSuggObj.getInt("dislike_s"));
            i ++;
        }
    
    int d = 0;
    
    
            }
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
 }
    public void addLike(int idSugg){
       int like;
    try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {

    Statement myStm = myConn.createStatement();
    ResultSet allSuggObj = myStm.executeQuery("SELECT `like_s` FROM `suggest` WHERE `id_s`='"+idSugg+"'");
    
 
     allSuggObj.next();
            
        like = allSuggObj.getInt("like_s");
 like ++;

      myStm.executeUpdate( "UPDATE `suggest` SET `like_s` = "+like+" WHERE `id_s`='"+idSugg+"'");
        
    
 
    
    
            }
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
        
    
    
    } 
    public void addDislike(int idSugg){
       int dislike;
    try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {

    Statement myStm = myConn.createStatement();
    ResultSet allSuggObj = myStm.executeQuery("SELECT `dislike_s` FROM `suggest` WHERE `id_s`='"+idSugg+"'");
    
 
     allSuggObj.next();
            
        dislike = allSuggObj.getInt("dislike_s");
 dislike ++;

      myStm.executeUpdate( "UPDATE `suggest` SET `dislike_s` = "+dislike+" WHERE `id_s`='"+idSugg+"'");
        
    
 
    
    
            }
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
        
    
    
    } 
    public void addAbuse(int idSugg){
       int abuse;
    try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {

    Statement myStm = myConn.createStatement();
    ResultSet allSuggObj = myStm.executeQuery("SELECT `abuse_s` FROM `suggest` WHERE `id_s`='"+idSugg+"'");
    
 
     allSuggObj.next();
            
        abuse = allSuggObj.getInt("abuse_s");
 abuse ++;

      myStm.executeUpdate( "UPDATE `suggest` SET `abuse_s` = "+abuse+" WHERE `id_s`='"+idSugg+"'");
        
    
 
    
    
            }
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
        
    
    
    }
    Driver d = new Driver();
    public void setInfoSugg(String descr,int idAccount){
         String sqlEx ; 
         sqlEx = "INSERT INTO `suggest`(`id_s`, `desc_s`, `dislike_s`, `like_s`, `abuse_s`, `id_u_s`) VALUES (NULL,'"+descr+"','0','0','0','"+idAccount+"')";
        d.executeStringUploadInMySQL(sqlEx);   
    }
    public String oneSugg (int id){    
        String desc;
        
    try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {

    Statement myStm = myConn.createStatement();
    ResultSet allSuggObj = myStm.executeQuery("SELECT `desc_s` FROM `suggest` WHERE `id_s`='"+id+"'");
    
 
     allSuggObj.next();
            
       desc  = allSuggObj.getString("desc_s");
       
 

      return desc;
        
    
 
    
    
            }
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   
    }
    
    return desc = "false";
    
    
    }
     public int findIdUFromSugg (int id){    
        
        
    try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {

    Statement myStm = myConn.createStatement();
    ResultSet allSuggObj = myStm.executeQuery("SELECT `id_s_u` FROM `suggest` WHERE `id_s`='"+id+"'");
    
 
     allSuggObj.next();
            
       id  = Integer.parseInt(allSuggObj.getString("id_s_u"));
       
 

      return id;
        
    
 
    
    
            }
   } catch (SQLException ex) {
            System.out.println("Errore selezionamento degli utenti che hanno scritto i Sugg");
     
   } catch (ClassNotFoundException e) {
       System.out.println("Errore selezionamento deglu utenti che hanno scritto i Sugg");    
   
    }
    
    return id = 0;
    
    
    }
     public void getSuggestByDislike() {
        
     try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {

    Statement myStm = myConn.createStatement();
    ResultSet allSuggObj = myStm.executeQuery("SELECT `id_s`, `desc_s`, `dislike_s`, `like_s`, `abuse_s`, `id_u_s` FROM `suggest` ORDER BY `dislike_s` DESC");
    
    int i = 0;
        while(allSuggObj.next()){
            maxSuggLike = i;
        id_s.add(i,allSuggObj.getInt("id_s"));
        id_s_u.add(i,allSuggObj.getInt("id_u_s"));
        desc_s.add(i,allSuggObj.getString("desc_s"));
        like_s.add(i,allSuggObj.getInt("like_s"));
        dislike_s.add(i,allSuggObj.getInt("dislike_s"));
            i ++;
        }
    
    int d = 0;
    
    
            }
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
 }
     public void getSuggestByMostrecent()  {
        
     try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {

    Statement myStm = myConn.createStatement();
    ResultSet allSuggObj = myStm.executeQuery("SELECT `id_s`, `desc_s`, `dislike_s`, `like_s`, `abuse_s`, `id_u_s` FROM `suggest` ORDER BY `id_s` DESC");
    
    int i = 0;
        while(allSuggObj.next()){
            maxSuggLike = i;
        id_s.add(i,allSuggObj.getInt("id_s"));
        
        System.out.println("da mostrecent in alla suggest: "+id_s.get(i));
        
        id_s_u.add(i,allSuggObj.getInt("id_u_s"));
        desc_s.add(i,allSuggObj.getString("desc_s"));
        like_s.add(i,allSuggObj.getInt("like_s"));
        dislike_s.add(i,allSuggObj.getInt("dislike_s"));
            i ++;
        }
    
    int d = 0;
    
    
            }
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
 }
      public void getSuggestByAbuse()  {
        
     try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {

    Statement myStm = myConn.createStatement();
    ResultSet allSuggObj = myStm.executeQuery("SELECT `id_s`, `desc_s`, `dislike_s`, `like_s`, `abuse_s`, `id_u_s` FROM `suggest` ORDER BY `abuse_s` DESC");
    
    int i = 0;
        while(allSuggObj.next()){
            maxSuggLike = i;
        id_s.add(i,allSuggObj.getInt("id_s"));
        id_s_u.add(i,allSuggObj.getInt("id_u_s"));
        desc_s.add(i,allSuggObj.getString("desc_s"));
        like_s.add(i,allSuggObj.getInt("like_s"));
        dislike_s.add(i,allSuggObj.getInt("dislike_s"));
            i ++;
        }
    
    int d = 0;
    
    
            }
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
 }
      public void getMySuggest(int id_admin)  {
        
     try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {

    Statement myStm = myConn.createStatement();
    ResultSet allSuggObj = myStm.executeQuery("SELECT `id_s`, `desc_s`, `dislike_s`, `like_s`, `abuse_s`, `id_u_s` FROM `suggest` WHERE `id_u_s` ='"+id_admin+"'");
    
    int i = 0;
        while(allSuggObj.next()){
            maxSuggLike = i;
        id_s.add(i,allSuggObj.getInt("id_s"));
        id_s_u.add(i,allSuggObj.getInt("id_u_s"));
        desc_s.add(i,allSuggObj.getString("desc_s"));
        like_s.add(i,allSuggObj.getInt("like_s"));
        dislike_s.add(i,allSuggObj.getInt("dislike_s"));
            i ++;
        }
    
    int d = 0;
    
    
            }
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
 }
    }
    
    
    
    
    
    
    
    
    
    

