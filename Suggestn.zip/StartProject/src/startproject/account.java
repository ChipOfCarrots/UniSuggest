/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author EliaPoli
 */
public class account {
    private String name_log;
    private String email_log;
    private int age_log;
    private int sex_log;
    private int id_log;
    private String picture_log;
    private int logId;//for admin
    
    Driver d = new Driver();
  
    private final String url1 = d.geturl();
    private final String user = d.getuser();
    private final String password = d.getpass();
    
    
    allUser u = new allUser();
    
    //serve per verificare se un account è registrato. 
    public void check_Account(String email,String password){
    
        id_log = u.findUserFromAccount(email, password);
        if (id_log > -1){
            System.out.println("Stai per essere Loggato");
        u.findAccountById(id_log);
        name_log = u.getNameA();
        email_log = u.getEmailA();
        age_log = u.getAgeA();
        sex_log = u.getSexA();
        picture_log  = u.getPictureA();
            u.resetA();
        }
        
    }
    
    //for newsuggest
    public int getAccountId(){
    return id_log;
    }
    
    public void check_Account_Admin(String email,String password){
    
        id_log = u.findUserFromAccount(email, password);
        if (id_log > -1){
            System.out.println("Stai per essere Loggato");
        u.findAccountById(id_log);
        name_log = u.getNameA();
        email_log = u.getEmailA();
        age_log = u.getAgeA();
        sex_log = u.getSexA();
        picture_log  = u.getPictureA();
            u.resetA();
        }
        
    }
    public int findAdminFromAccount(String nome, String pass){
     
      
     
     try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {
      
                
//System.out.println("hit");
                //se si è allacciato
    Statement myStm = myConn.createStatement();
    ResultSet myRs = myStm.executeQuery("SELECT * FROM `admin` WHERE `nome_a` = '"+nome+"' && `pass_a` ='"+pass+"'");
               
    myRs.next();
        if (myRs.wasNull()){
            //ritorna meno uno se non trova niente nella query 
            return logId = -1; 
            
        } else {
            logId = myRs.getInt("id_a");
            
            return logId;
               }
            }
   } catch (SQLException ex) {
            System.out.println("");
           
           

   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
   } 
    
   return logId = -1;  
 }
    
    
     public int getAccountAdminId(){
    return logId;
    }
    
    
    
}
