package startproject;
//import java sql library 
import java.sql.*;
/**
 *
 * @author Elia Poli
 *
 */
public class Driver {

    /*attibutes that allow database connection*/
    String url1 = "jdbc:mysql://localhost:3306/suggestn";
    String user = "root";
    String password = "";
    
       public void getConnToDb() {
           //to test DatabaseConnection
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection myConn = DriverManager.getConnection(url1, user, password);
                    //se si è allacciato
                    if (myConn != null) 
                    {
                        System.out.println("You are Connected");
                    }
                }
                catch (SQLException ex) 
                {
                    System.out.println("An error occurred. Maybe user/password is invalid");
                    ex.printStackTrace();
                } 
                catch (ClassNotFoundException e) 
                {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }       
}

public void executeStringUploadInMySQL(String sqlEx){
    try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {
//System.out.println("hit");
//se si è allacciato
    Statement myStm = myConn.createStatement();
    myStm.executeUpdate(sqlEx);
            System.out.println("Record Upload");
            myConn.close();    
            }
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
           

   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }       
}

public String getpass(){
    return password;
}

public String geturl(){
    return url1;
}
public String getuser(){
    return user;
}

public boolean checkEmailOrNameNewuser(String email, String nome){
    boolean yesorno = false;
      
     try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {
      
                
//System.out.println("hit");
                //se si è allacciato
    Statement myStm = myConn.createStatement();
    ResultSet UserObj = myStm.executeQuery("SELECT * FROM `user` WHERE `email_u`= '"+email+"' && `name_u`= '"+nome+"'");
  
    //ritorna falso se lo trova
    
                if (UserObj == null){
                    yesorno = false;  
                    System.out.println("in driver "+ yesorno);

                return yesorno = false;
                }else{
                    yesorno = true;  
                    System.out.println("in driver "+ yesorno);
                return yesorno = true;
                }
    
            }
   } catch (SQLException ex) {
System.out.println("in driver "+ yesorno);
       return yesorno = true;
   } catch (ClassNotFoundException e) {
    
System.out.println("in driver "+ yesorno);// TODO Auto-generated catch block
       return yesorno = true;
   }
    
    
    
return yesorno;
}

public void executeStringDeleteInMySQL(String sqlEx){
    try {
           Class.forName("com.mysql.jdbc.Driver");
            // connect way #1
          
        Connection myConn = DriverManager.getConnection(url1, user, password);
            if (myConn != null) {
//System.out.println("hit");
//se si è allacciato
    Statement myStm = myConn.createStatement();
    myStm.executeUpdate(sqlEx);
            System.out.println("Deleted row");
            myConn.close();    
            }
   } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
           

   } catch (ClassNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }       
}

}
